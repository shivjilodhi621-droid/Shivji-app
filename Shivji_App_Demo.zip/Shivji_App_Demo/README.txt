SHIVJI APP - INTERACTIVE DEMO
1. Extract this ZIP on your phone or computer.
2. Open index.html in Chrome.
3. Tap the tiles to show Home, Chat, Calls, Profile and Payment demo screens.

This is a clickable presentation prototype, NOT an installable APK.
Real chat/calls/payments require backend services, authentication, privacy/security work,
and a payment provider integration. No real payments or communications are performed.
