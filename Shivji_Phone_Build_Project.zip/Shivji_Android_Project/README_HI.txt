SHIVJI ANDROID PROJECT (DEMO)

यह Android Studio का शुरुआती प्रोजेक्ट है। इसमें पहले बनाया गया Shivji क्लिक करने योग्य डेमो Android WebView में खुलता है।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में इस फोल्डर को Open करें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

सीमाएँ:
- यह तैयार APK नहीं, बल्कि Android Studio source project है।
- चैट केवल स्थानीय डेमो है; दूसरे यूज़र तक मैसेज नहीं जाता।
- ऑडियो/वीडियो कॉल वास्तविक रूप से कनेक्ट नहीं हैं।
- पेमेंट स्क्रीन केवल डेमो है; कोई भुगतान नहीं होता।
- असली उपयोग से पहले सुरक्षित backend, user authentication, privacy/security review,
  calling infrastructure और अधिकृत payment gateway जोड़ना व परीक्षण करना होगा।

PHONE-ONLY BUILD OPTION (GitHub Actions)
1. Phone browser में github.com खोलकर account बनाएं/Sign in करें।
2. New repository बनाएं; नाम Shivji रखें और Public या Private चुनें।
3. इस ZIP को फोन में Extract करें। GitHub वेबसाइट पर repository में Add file > Upload files से सभी project files और .github folder सहित upload करें, फिर Commit changes करें।
4. Repository के Actions tab में “Build Shivji APK” workflow चुनें और Run workflow दबाएँ।
5. Build सफल होने पर workflow run खोलें; नीचे Artifacts में Shivji-debug-APK डाउनलोड करें। ZIP खोलकर app-debug.apk निकालें।
6. APK केवल अपने भरोसेमंद डिवाइस पर इंस्टॉल करें; Android अज्ञात स्रोत से इंस्टॉल की अनुमति पूछ सकता है।

GitHub account/repository और इंटरनेट आवश्यक हैं। यह तरीका APK build करने का automated workflow देता है; build सफल होने की पुष्टि workflow पूरा होने के बाद ही होगी।
