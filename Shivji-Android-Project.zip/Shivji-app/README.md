# Shivji Android App — Demo v0.1

This repository contains an initial native Android UI prototype built with Kotlin and Jetpack Compose.

## Current demo includes
- Shivji home screen and maroon/cream theme
- Hindi/English language toggle
- Navigation cards for Home, Chat, Videos and Profile
- Clear placeholders describing modules that still need backend work

## Not included yet
- Real user accounts/authentication
- Live chat or calling server
- Video hosting/streaming backend
- Payment gateway or money transfers
- Production security, privacy policy, moderation and deployment

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Package: `com.shivji.app`

This is a demo starter, not a production-ready app. Never add passwords, API keys, payment secrets, or private user data to GitHub.
