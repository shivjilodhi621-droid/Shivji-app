package com.shivji.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Maroon = Color(0xFF641B2B)
private val Cream = Color(0xFFFFF8F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShivjiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShivjiApp() {
    var page by remember { mutableStateOf("Home") }
    var hindi by remember { mutableStateOf(true) }
    val labels = if (hindi) listOf("होम", "चैट", "वीडियो", "प्रोफाइल") else listOf("Home", "Chat", "Videos", "Profile")
    val pages = listOf("Home", "Chat", "Videos", "Profile")
    Scaffold(
        containerColor = Cream,
        topBar = {
            TopAppBar(
                title = { Text("Shivji", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 23.sp) },
                actions = { TextButton(onClick = { hindi = !hindi }) { Text(if (hindi) "EN" else "हिं", color = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Maroon)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                pages.forEachIndexed { i, p ->
                    NavigationBarItem(selected = page == p, onClick = { page = p },
                        icon = { Icon(when (p) { "Home" -> Icons.Default.Home; "Chat" -> Icons.Default.Chat; "Videos" -> Icons.Default.PlayCircle; else -> Icons.Default.Person }, contentDescription = labels[i]) },
                        label = { Text(labels[i]) })
                }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Column(Modifier.fillMaxWidth().background(Maroon, RoundedCornerShape(20.dp)).padding(22.dp)) {
                    Text(if (hindi) "नमस्ते, शिवजी!" else "Welcome to Shivji!", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(if (hindi) "आपका पर्सनल कम्युनिटी ऐप" else "Your personal community app", color = Color.White.copy(alpha = .9f))
                }
            }
            item { Text(if (hindi) "मुख्य सुविधाएँ" else "Quick access", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Maroon) }
            item { FeatureCard("💬", if (hindi) "मैसेज और चैट" else "Messages & Chat", if (hindi) "चैट सुविधा — सर्वर जोड़ना बाकी" else "Chat module — backend setup pending") { page = "Chat" } }
            item { FeatureCard("▶️", if (hindi) "वीडियो" else "Videos", if (hindi) "वीडियो सेक्शन का डेमो" else "Video section preview") { page = "Videos" } }
            item { FeatureCard("👤", if (hindi) "प्रोफाइल" else "Profile", if (hindi) "अपनी प्रोफाइल जानकारी" else "Your profile information") { page = "Profile" } }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(when(page) { "Chat" -> if(hindi) "चैट डेमो" else "Chat demo"; "Videos" -> if(hindi) "वीडियो डेमो" else "Video demo"; "Profile" -> if(hindi) "प्रोफाइल डेमो" else "Profile demo"; else -> if(hindi) "ऐप की स्थिति" else "Project status" }, fontWeight = FontWeight.Bold, color = Maroon)
                        Spacer(Modifier.height(6.dp))
                        Text(if (hindi) "यह शुरुआती Android UI प्रोटोटाइप है। लाइव चैट, वीडियो स्ट्रीमिंग, लॉगिन, सर्वर और सुरक्षित भुगतान अभी जुड़े नहीं हैं। भुगतान सुविधा को वास्तविक उपयोग से पहले सत्यापित सुरक्षित पेमेंट प्रदाता और वयस्क/कंपनी की अनुमति के साथ ही जोड़ा जाना चाहिए।" else "This is an initial Android UI prototype. Live chat, video streaming, login, backend server and secure payments are not connected yet.")
                    }
                }
            }
            item { Text("Shivji • Demo v0.1", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally)) }
        }
    }
}

@Composable
fun FeatureCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 28.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Maroon)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Maroon)
        }
    }
}
