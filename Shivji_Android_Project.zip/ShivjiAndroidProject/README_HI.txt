SHIVJI Android starter project — demo build

इस ZIP में:
- Android Studio में खुलने वाला Android/Kotlin प्रोजेक्ट
- ऐप के अंदर चलने वाला मौजूदा SHIVJI HTML डेमो
- Maroon थीम वाला शुरुआती UI

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio (और Android SDK 35) इंस्टॉल करें।
2. Android Studio में इस फोल्डर को Open करें।
3. Gradle Sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगी।

महत्वपूर्ण स्थिति:
यह अभी DEMO/STARTER है, पूरा लाइव मैसेजिंग ऐप नहीं। इसमें असली OTP/login,
server/database, real-time chat, audio/video calling, push notifications और
payment gateway अभी जुड़े/टेस्ट नहीं हुए हैं। असली पेमेंट के लिए अधिकृत
payment provider onboarding और server-side verification जरूरी है।
किसी वास्तविक बैंक/UPI भुगतान को इस डेमो से न करें।
