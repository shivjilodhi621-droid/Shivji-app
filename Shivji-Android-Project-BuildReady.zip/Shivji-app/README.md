# Shivji Android Demo (v0.1)

A starter Android app UI prototype built with Kotlin and Jetpack Compose.

## Included
- Hindi/English toggle
- Home, Chat, Videos and Profile demo sections
- Maroon theme

## Not connected yet
Live chat, video calling/streaming, user authentication, backend/server, and payments are not implemented. This is a demo UI, not a production-ready app.

## Build APK with GitHub Actions
1. Upload the **contents** of this project folder to the root of your GitHub repository (not just the ZIP file).
2. Open the repository's **Actions** tab.
3. Select **Build Shivji Android APK** and choose **Run workflow** (or push a commit to `main`).
4. When the run finishes, open it and download the `Shivji-debug-apk` artifact.
5. Extract the artifact ZIP; it contains `app-debug.apk`.

The APK is a debug/demo build. Do not use it for public release without production security, testing, privacy review, and a properly signed release build.
