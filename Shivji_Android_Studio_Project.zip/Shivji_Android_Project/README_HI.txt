SHIVJI ANDROID PROJECT (DEMO)

यह Android Studio का शुरुआती प्रोजेक्ट है। इसमें पहले बनाया गया Shivji क्लिक करने योग्य डेमो Android WebView में खुलता है।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में इस फोल्डर को Open करें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

सीमाएँ:
- यह तैयार APK नहीं, बल्कि Android Studio source project है।
- चैट केवल स्थानीय डेमो है; दूसरे यूज़र तक मैसेज नहीं जाता।
- ऑडियो/वीडियो कॉल वास्तविक रूप से कनेक्ट नहीं हैं।
- पेमेंट स्क्रीन केवल डेमो है; कोई भुगतान नहीं होता।
- असली उपयोग से पहले सुरक्षित backend, user authentication, privacy/security review,
  calling infrastructure और अधिकृत payment gateway जोड़ना व परीक्षण करना होगा।
